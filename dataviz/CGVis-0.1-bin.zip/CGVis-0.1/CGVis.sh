#!/bin/sh
java -Xmx256M -cp "./CGVis.jar:./extra/mysql-connector-java-3.1.12-bin.jar" at.fhjoanneum.cgvis.CGVis &
